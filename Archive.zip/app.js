var express = require('express'),
	mongoose = require('mongoose'),
	app = express(),
	router = express.Router();


var db = mongoose.connect('mongodb://localhost/bookAPI');


var Book = require('./models/bookModel');


router = require('./routes/bookRoutes')(Book);

app.use('/api', router);

app.use('/', function(req, res){
	res.send('welcome to my api');
});

app.listen(8000, function(){
	console.log('server listening on port 8080');
});

