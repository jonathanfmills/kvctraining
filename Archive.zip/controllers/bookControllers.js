

var bookControllers = function(Book){


var Find = function (req, res) {
		Book.find(function(err, books){
			if(err)
			{
				console.log(err);
			}
			else
			{
				res.json(books);
			}
		});
	}

	return{
		find: Find
	}

}

module.exports = bookControllers